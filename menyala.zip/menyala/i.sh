pkg update
pkg install x11-repo
pkg install termux-x11-nightly
pkg install pulseaudio
pkg install xfce4
pkg install tur-repo
pkg install chromium
pkg install tur-repo
pkg install code-oss
pkg install wget
wget https://raw.githubusercontent.com/LinuxDroidMaster/Termux-Desktops/main/scripts/termux_native/startxfce4_termux.sh
mv startxfce4_termux.sh home
chmod +x home
echo "run ./home"
